


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";






CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer DEFAULT 5) RETURNS TABLE("editor_nickname" "text", "edit_count" bigint, "last_edit" timestamp without time zone)
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  RETURN QUERY
  SELECT
    me.editor_nickname,
    COUNT(*) as edit_count,
    MAX(me.created_at) as last_edit
  FROM medley_edits me
  WHERE me.medley_id = medley_uuid
  GROUP BY me.editor_nickname
  ORDER BY edit_count DESC, last_edit DESC
  LIMIT limit_count;
END;
$$;


ALTER FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_last_edited_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.last_edited_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_last_edited_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_song_data_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_song_data_updated_at"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."medley_edits" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "medley_id" "uuid",
    "editor_nickname" "text" NOT NULL,
    "action" "text" NOT NULL,
    "changes" "jsonb",
    "created_at" timestamp without time zone DEFAULT "now"(),
    CONSTRAINT "medley_edits_action_check" CHECK (("action" = ANY (ARRAY['create'::"text", 'update'::"text", 'delete'::"text", 'song_add'::"text", 'song_update'::"text", 'song_delete'::"text"])))
);


ALTER TABLE "public"."medley_edits" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."medleys" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "video_id" character varying(20) NOT NULL,
    "title" "text" NOT NULL,
    "creator" "text",
    "duration" integer NOT NULL,
    "initial_bpm" integer DEFAULT 120,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_editor" "text",
    "last_edited_at" timestamp without time zone DEFAULT "now"()
);


ALTER TABLE "public"."medleys" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."song_data" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title" "text" NOT NULL,
    "artist" "text" NOT NULL,
    "original_link" "text",
    "links" "jsonb",
    "normalized_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."song_data" OWNER TO "postgres";


COMMENT ON TABLE "public"."song_data" IS 'Stores manually added songs for reuse across medleys. Duplicate detection uses normalized_id.';



CREATE TABLE IF NOT EXISTS "public"."songs" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "medley_id" "uuid" NOT NULL,
    "title" "text" NOT NULL,
    "artist" "text",
    "start_time" integer NOT NULL,
    "end_time" integer NOT NULL,
    "color" character varying(50) NOT NULL,
    "genre" "text",
    "original_link" "text",
    "order_index" integer NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_editor" "text",
    "last_edited_at" timestamp without time zone DEFAULT "now"()
);


ALTER TABLE "public"."songs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."tempo_changes" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "medley_id" "uuid" NOT NULL,
    "time" integer NOT NULL,
    "bpm" integer NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tempo_changes" OWNER TO "postgres";


ALTER TABLE ONLY "public"."medley_edits"
    ADD CONSTRAINT "medley_edits_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."medleys"
    ADD CONSTRAINT "medleys_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."medleys"
    ADD CONSTRAINT "medleys_video_id_key" UNIQUE ("video_id");



ALTER TABLE ONLY "public"."song_data"
    ADD CONSTRAINT "song_data_normalized_id_key" UNIQUE ("normalized_id");



ALTER TABLE ONLY "public"."song_data"
    ADD CONSTRAINT "song_data_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."songs"
    ADD CONSTRAINT "songs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."tempo_changes"
    ADD CONSTRAINT "tempo_changes_pkey" PRIMARY KEY ("id");



CREATE INDEX "idx_medley_edits_created_at" ON "public"."medley_edits" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_medley_edits_editor" ON "public"."medley_edits" USING "btree" ("editor_nickname");



CREATE INDEX "idx_medley_edits_medley_id" ON "public"."medley_edits" USING "btree" ("medley_id");



CREATE INDEX "idx_medleys_video_id" ON "public"."medleys" USING "btree" ("video_id");



CREATE INDEX "idx_song_data_artist" ON "public"."song_data" USING "btree" ("artist");



CREATE INDEX "idx_song_data_created_at" ON "public"."song_data" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_song_data_normalized_id" ON "public"."song_data" USING "btree" ("normalized_id");



CREATE INDEX "idx_song_data_title" ON "public"."song_data" USING "btree" ("title");



CREATE INDEX "idx_songs_medley_id" ON "public"."songs" USING "btree" ("medley_id");



CREATE INDEX "idx_songs_order_index" ON "public"."songs" USING "btree" ("order_index");



CREATE INDEX "idx_tempo_changes_medley_id" ON "public"."tempo_changes" USING "btree" ("medley_id");



CREATE INDEX "idx_tempo_changes_time" ON "public"."tempo_changes" USING "btree" ("time");



CREATE OR REPLACE TRIGGER "song_data_updated_at" BEFORE UPDATE ON "public"."song_data" FOR EACH ROW EXECUTE FUNCTION "public"."update_song_data_updated_at"();



CREATE OR REPLACE TRIGGER "update_medleys_last_edited_at" BEFORE UPDATE ON "public"."medleys" FOR EACH ROW EXECUTE FUNCTION "public"."update_last_edited_at"();



CREATE OR REPLACE TRIGGER "update_songs_last_edited_at" BEFORE UPDATE ON "public"."songs" FOR EACH ROW EXECUTE FUNCTION "public"."update_last_edited_at"();



ALTER TABLE ONLY "public"."medley_edits"
    ADD CONSTRAINT "medley_edits_medley_id_fkey" FOREIGN KEY ("medley_id") REFERENCES "public"."medleys"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."songs"
    ADD CONSTRAINT "songs_medley_id_fkey" FOREIGN KEY ("medley_id") REFERENCES "public"."medleys"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."tempo_changes"
    ADD CONSTRAINT "tempo_changes_medley_id_fkey" FOREIGN KEY ("medley_id") REFERENCES "public"."medleys"("id") ON DELETE CASCADE;



CREATE POLICY "Allow public delete access to song_data" ON "public"."song_data" FOR DELETE USING (true);



CREATE POLICY "Allow public delete on songs" ON "public"."songs" FOR DELETE USING (true);



CREATE POLICY "Allow public delete on tempo_changes" ON "public"."tempo_changes" FOR DELETE USING (true);



CREATE POLICY "Allow public insert access to song_data" ON "public"."song_data" FOR INSERT WITH CHECK (true);



CREATE POLICY "Allow public insert on medleys" ON "public"."medleys" FOR INSERT WITH CHECK (true);



CREATE POLICY "Allow public insert on songs" ON "public"."songs" FOR INSERT WITH CHECK (true);



CREATE POLICY "Allow public insert on tempo_changes" ON "public"."tempo_changes" FOR INSERT WITH CHECK (true);



CREATE POLICY "Allow public read access on medleys" ON "public"."medleys" FOR SELECT USING (true);



CREATE POLICY "Allow public read access on songs" ON "public"."songs" FOR SELECT USING (true);



CREATE POLICY "Allow public read access on tempo_changes" ON "public"."tempo_changes" FOR SELECT USING (true);



CREATE POLICY "Allow public read access to song_data" ON "public"."song_data" FOR SELECT USING (true);



CREATE POLICY "Allow public update access to song_data" ON "public"."song_data" FOR UPDATE USING (true) WITH CHECK (true);



CREATE POLICY "Allow public update on medleys" ON "public"."medleys" FOR UPDATE USING (true);



CREATE POLICY "Allow public update on songs" ON "public"."songs" FOR UPDATE USING (true);



CREATE POLICY "Allow public update on tempo_changes" ON "public"."tempo_changes" FOR UPDATE USING (true);



CREATE POLICY "Anyone can delete medleys" ON "public"."medleys" FOR DELETE USING (true);



CREATE POLICY "Anyone can delete songs" ON "public"."songs" FOR DELETE USING (true);



CREATE POLICY "Anyone can insert medleys" ON "public"."medleys" FOR INSERT WITH CHECK (true);



CREATE POLICY "Anyone can insert songs" ON "public"."songs" FOR INSERT WITH CHECK (true);



CREATE POLICY "Anyone can update medleys" ON "public"."medleys" FOR UPDATE USING (true);



CREATE POLICY "Anyone can update songs" ON "public"."songs" FOR UPDATE USING (true);



CREATE POLICY "Anyone can view edit history" ON "public"."medley_edits" FOR SELECT USING (true);



CREATE POLICY "Anyone can view medleys" ON "public"."medleys" FOR SELECT USING (true);



CREATE POLICY "Anyone can view songs" ON "public"."songs" FOR SELECT USING (true);



CREATE POLICY "Authenticated users can insert edit history" ON "public"."medley_edits" FOR INSERT WITH CHECK (true);



ALTER TABLE "public"."medley_edits" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."medleys" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."song_data" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."songs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."tempo_changes" ENABLE ROW LEVEL SECURITY;




ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";


GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";

























































































































































GRANT ALL ON FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer) TO "anon";
GRANT ALL ON FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."update_last_edited_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_last_edited_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_last_edited_at"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_song_data_updated_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_song_data_updated_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_song_data_updated_at"() TO "service_role";


















GRANT ALL ON TABLE "public"."medley_edits" TO "anon";
GRANT ALL ON TABLE "public"."medley_edits" TO "authenticated";
GRANT ALL ON TABLE "public"."medley_edits" TO "service_role";



GRANT ALL ON TABLE "public"."medleys" TO "anon";
GRANT ALL ON TABLE "public"."medleys" TO "authenticated";
GRANT ALL ON TABLE "public"."medleys" TO "service_role";



GRANT ALL ON TABLE "public"."song_data" TO "anon";
GRANT ALL ON TABLE "public"."song_data" TO "authenticated";
GRANT ALL ON TABLE "public"."song_data" TO "service_role";



GRANT ALL ON TABLE "public"."songs" TO "anon";
GRANT ALL ON TABLE "public"."songs" TO "authenticated";
GRANT ALL ON TABLE "public"."songs" TO "service_role";



GRANT ALL ON TABLE "public"."tempo_changes" TO "anon";
GRANT ALL ON TABLE "public"."tempo_changes" TO "authenticated";
GRANT ALL ON TABLE "public"."tempo_changes" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































RESET ALL;
