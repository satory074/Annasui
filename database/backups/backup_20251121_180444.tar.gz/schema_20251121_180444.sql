


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";






CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer DEFAULT 5) RETURNS TABLE("editor_nickname" "text", "edit_count" bigint, "last_edit" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  RETURN QUERY
  SELECT
    me.editor_nickname,
    COUNT(*) as edit_count,
    MAX(me.created_at) as last_edit
  FROM medley_edits me
  WHERE me.medley_id = medley_uuid
  GROUP BY me.editor_nickname
  ORDER BY edit_count DESC, last_edit DESC
  LIMIT limit_count;
END;
$$;


ALTER FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_last_edited_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.last_edited_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_last_edited_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_song_master_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_song_master_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_updated_at_column"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."artists" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "normalized_name" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."artists" OWNER TO "postgres";


COMMENT ON TABLE "public"."artists" IS 'Master table for all artists, composers, and arrangers';



COMMENT ON COLUMN "public"."artists"."name" IS 'Display name of the artist';



COMMENT ON COLUMN "public"."artists"."normalized_name" IS 'Normalized name for duplicate detection (katakana→hiragana, symbols removed)';



CREATE TABLE IF NOT EXISTS "public"."medley_edits" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "medley_id" "uuid",
    "song_id" "uuid",
    "editor_nickname" "text" NOT NULL,
    "action" character varying(50) NOT NULL,
    "changes" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "action_check" CHECK ((("action")::"text" = ANY ((ARRAY['create_medley'::character varying, 'update_medley'::character varying, 'delete_medley'::character varying, 'add_song'::character varying, 'update_song'::character varying, 'delete_song'::character varying, 'reorder_songs'::character varying])::"text"[])))
);


ALTER TABLE "public"."medley_edits" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."medley_songs" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "medley_id" "uuid" NOT NULL,
    "song_id" "uuid",
    "start_time" integer NOT NULL,
    "end_time" integer NOT NULL,
    "order_index" integer NOT NULL,
    "title" "text" NOT NULL,
    "artist" "text" NOT NULL,
    "color" character varying(20) DEFAULT '#3B82F6'::character varying,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_editor" "text",
    "last_edited_at" timestamp with time zone DEFAULT "now"(),
    "niconico_link" "text",
    "youtube_link" "text",
    "spotify_link" "text",
    "applemusic_link" "text",
    "composers" "text",
    "arrangers" "text",
    CONSTRAINT "valid_time_range" CHECK (("end_time" > "start_time"))
);


ALTER TABLE "public"."medley_songs" OWNER TO "postgres";


COMMENT ON COLUMN "public"."medley_songs"."composers" IS 'Cached comma-separated list of composers for display (source: song_artist_relations with role=composer)';



COMMENT ON COLUMN "public"."medley_songs"."arrangers" IS 'Cached comma-separated list of arrangers for display (source: song_artist_relations with role=arranger)';



CREATE TABLE IF NOT EXISTS "public"."medleys" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "video_id" character varying NOT NULL,
    "platform" character varying(20) DEFAULT 'niconico'::character varying NOT NULL,
    "title" "text" NOT NULL,
    "creator" "text",
    "duration" integer NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_editor" "text",
    "last_edited_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "platform_check" CHECK ((("platform")::"text" = ANY ((ARRAY['niconico'::character varying, 'youtube'::character varying, 'spotify'::character varying, 'appleMusic'::character varying])::"text"[])))
);


ALTER TABLE "public"."medleys" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."song_artist_relations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "song_id" "uuid" NOT NULL,
    "artist_id" "uuid" NOT NULL,
    "role" "text" NOT NULL,
    "order_index" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "song_artist_relations_role_check" CHECK (("role" = ANY (ARRAY['artist'::"text", 'composer'::"text", 'arranger'::"text"])))
);


ALTER TABLE "public"."song_artist_relations" OWNER TO "postgres";


COMMENT ON TABLE "public"."song_artist_relations" IS 'Many-to-many relations between songs and artists with roles';



COMMENT ON COLUMN "public"."song_artist_relations"."role" IS 'Role: artist (performer), composer (music creator), arranger (arrangement creator)';



COMMENT ON COLUMN "public"."song_artist_relations"."order_index" IS 'Display order when multiple artists have the same role (0-based)';



CREATE TABLE IF NOT EXISTS "public"."song_master" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title" "text" NOT NULL,
    "artist" "text",
    "normalized_id" "text" NOT NULL,
    "description" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "niconico_link" "text",
    "youtube_link" "text",
    "spotify_link" "text",
    "applemusic_link" "text",
    CONSTRAINT "unique_song" CHECK (("title" <> ''::"text"))
);


ALTER TABLE "public"."song_master" OWNER TO "postgres";


COMMENT ON TABLE "public"."song_master" IS 'Stores manually added songs for reuse across medleys. Duplicate detection uses normalized_id.';



ALTER TABLE ONLY "public"."artists"
    ADD CONSTRAINT "artists_normalized_name_key" UNIQUE ("normalized_name");



ALTER TABLE ONLY "public"."artists"
    ADD CONSTRAINT "artists_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."medley_edits"
    ADD CONSTRAINT "medley_edits_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."medley_songs"
    ADD CONSTRAINT "medley_songs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."medleys"
    ADD CONSTRAINT "medleys_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."medleys"
    ADD CONSTRAINT "medleys_video_id_key" UNIQUE ("video_id");



ALTER TABLE ONLY "public"."song_artist_relations"
    ADD CONSTRAINT "song_artist_relations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."song_master"
    ADD CONSTRAINT "song_master_normalized_id_key" UNIQUE ("normalized_id");



ALTER TABLE ONLY "public"."song_master"
    ADD CONSTRAINT "song_master_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."medley_songs"
    ADD CONSTRAINT "unique_position" UNIQUE ("medley_id", "order_index");



CREATE INDEX "idx_artists_normalized_name" ON "public"."artists" USING "btree" ("normalized_name");



CREATE INDEX "idx_medley_edits_created_at" ON "public"."medley_edits" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_medley_edits_editor" ON "public"."medley_edits" USING "btree" ("editor_nickname");



CREATE INDEX "idx_medley_edits_medley_id" ON "public"."medley_edits" USING "btree" ("medley_id");



CREATE INDEX "idx_medley_edits_song_id" ON "public"."medley_edits" USING "btree" ("song_id");



CREATE INDEX "idx_medley_songs_applemusic" ON "public"."medley_songs" USING "btree" ("applemusic_link") WHERE ("applemusic_link" IS NOT NULL);



CREATE INDEX "idx_medley_songs_medley_id" ON "public"."medley_songs" USING "btree" ("medley_id");



CREATE INDEX "idx_medley_songs_niconico" ON "public"."medley_songs" USING "btree" ("niconico_link") WHERE ("niconico_link" IS NOT NULL);



CREATE INDEX "idx_medley_songs_order" ON "public"."medley_songs" USING "btree" ("medley_id", "order_index");



CREATE INDEX "idx_medley_songs_song_id" ON "public"."medley_songs" USING "btree" ("song_id");



CREATE INDEX "idx_medley_songs_spotify" ON "public"."medley_songs" USING "btree" ("spotify_link") WHERE ("spotify_link" IS NOT NULL);



CREATE INDEX "idx_medley_songs_youtube" ON "public"."medley_songs" USING "btree" ("youtube_link") WHERE ("youtube_link" IS NOT NULL);



CREATE INDEX "idx_medleys_creator" ON "public"."medleys" USING "btree" ("creator");



CREATE INDEX "idx_medleys_platform" ON "public"."medleys" USING "btree" ("platform");



CREATE INDEX "idx_medleys_video_id" ON "public"."medleys" USING "btree" ("video_id");



CREATE INDEX "idx_song_artist_artist_id" ON "public"."song_artist_relations" USING "btree" ("artist_id");



CREATE INDEX "idx_song_artist_role" ON "public"."song_artist_relations" USING "btree" ("role");



CREATE INDEX "idx_song_artist_song_id" ON "public"."song_artist_relations" USING "btree" ("song_id");



CREATE INDEX "idx_song_artist_song_role" ON "public"."song_artist_relations" USING "btree" ("song_id", "role");



CREATE UNIQUE INDEX "idx_song_artist_unique" ON "public"."song_artist_relations" USING "btree" ("song_id", "artist_id", "role");



CREATE INDEX "idx_song_master_applemusic" ON "public"."song_master" USING "btree" ("applemusic_link") WHERE ("applemusic_link" IS NOT NULL);



CREATE INDEX "idx_song_master_artist" ON "public"."song_master" USING "btree" ("artist");



CREATE INDEX "idx_song_master_empty_artist" ON "public"."song_master" USING "btree" ("artist") WHERE (("artist" = ''::"text") OR ("artist" IS NULL));



CREATE INDEX "idx_song_master_niconico" ON "public"."song_master" USING "btree" ("niconico_link") WHERE ("niconico_link" IS NOT NULL);



CREATE INDEX "idx_song_master_normalized_id" ON "public"."song_master" USING "btree" ("normalized_id");



CREATE INDEX "idx_song_master_spotify" ON "public"."song_master" USING "btree" ("spotify_link") WHERE ("spotify_link" IS NOT NULL);



CREATE INDEX "idx_song_master_title" ON "public"."song_master" USING "btree" ("title");



CREATE INDEX "idx_song_master_youtube" ON "public"."song_master" USING "btree" ("youtube_link") WHERE ("youtube_link" IS NOT NULL);



CREATE OR REPLACE TRIGGER "song_master_updated_at" BEFORE UPDATE ON "public"."song_master" FOR EACH ROW EXECUTE FUNCTION "public"."update_song_master_updated_at"();



CREATE OR REPLACE TRIGGER "update_artists_updated_at" BEFORE UPDATE ON "public"."artists" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();



CREATE OR REPLACE TRIGGER "update_medley_songs_last_edited_at" BEFORE UPDATE ON "public"."medley_songs" FOR EACH ROW EXECUTE FUNCTION "public"."update_last_edited_at"();



CREATE OR REPLACE TRIGGER "update_medleys_last_edited_at" BEFORE UPDATE ON "public"."medleys" FOR EACH ROW EXECUTE FUNCTION "public"."update_last_edited_at"();



ALTER TABLE ONLY "public"."medley_edits"
    ADD CONSTRAINT "medley_edits_medley_id_fkey" FOREIGN KEY ("medley_id") REFERENCES "public"."medleys"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."medley_songs"
    ADD CONSTRAINT "medley_songs_medley_id_fkey" FOREIGN KEY ("medley_id") REFERENCES "public"."medleys"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."medley_songs"
    ADD CONSTRAINT "medley_songs_song_id_fkey" FOREIGN KEY ("song_id") REFERENCES "public"."song_master"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."song_artist_relations"
    ADD CONSTRAINT "song_artist_relations_artist_id_fkey" FOREIGN KEY ("artist_id") REFERENCES "public"."artists"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."song_artist_relations"
    ADD CONSTRAINT "song_artist_relations_song_id_fkey" FOREIGN KEY ("song_id") REFERENCES "public"."song_master"("id") ON DELETE CASCADE;



CREATE POLICY "Allow all operations on artists" ON "public"."artists" USING (true) WITH CHECK (true);



CREATE POLICY "Allow all operations on song_artist_relations" ON "public"."song_artist_relations" USING (true) WITH CHECK (true);



CREATE POLICY "Allow public read access to artists" ON "public"."artists" FOR SELECT USING (true);



CREATE POLICY "Allow public read access to song_artist_relations" ON "public"."song_artist_relations" FOR SELECT USING (true);



CREATE POLICY "Anyone can delete medley_songs" ON "public"."medley_songs" FOR DELETE USING (true);



CREATE POLICY "Anyone can delete medleys" ON "public"."medleys" FOR DELETE USING (true);



CREATE POLICY "Anyone can delete song_master" ON "public"."song_master" FOR DELETE USING (true);



CREATE POLICY "Anyone can insert medley_songs" ON "public"."medley_songs" FOR INSERT WITH CHECK (true);



CREATE POLICY "Anyone can insert medleys" ON "public"."medleys" FOR INSERT WITH CHECK (true);



CREATE POLICY "Anyone can insert song_master" ON "public"."song_master" FOR INSERT WITH CHECK (true);



CREATE POLICY "Anyone can update medley_songs" ON "public"."medley_songs" FOR UPDATE USING (true);



CREATE POLICY "Anyone can update medleys" ON "public"."medleys" FOR UPDATE USING (true);



CREATE POLICY "Anyone can update song_master" ON "public"."song_master" FOR UPDATE USING (true);



CREATE POLICY "Anyone can view edit history" ON "public"."medley_edits" FOR SELECT USING (true);



CREATE POLICY "Anyone can view medley_songs" ON "public"."medley_songs" FOR SELECT USING (true);



CREATE POLICY "Anyone can view medleys" ON "public"."medleys" FOR SELECT USING (true);



CREATE POLICY "Anyone can view song_master" ON "public"."song_master" FOR SELECT USING (true);



CREATE POLICY "Authenticated users can insert edit history" ON "public"."medley_edits" FOR INSERT WITH CHECK (true);



ALTER TABLE "public"."artists" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."medley_edits" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."medley_songs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."medleys" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."song_artist_relations" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."song_master" ENABLE ROW LEVEL SECURITY;




ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";


GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";

























































































































































GRANT ALL ON FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer) TO "anon";
GRANT ALL ON FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_medley_contributors"("medley_uuid" "uuid", "limit_count" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."update_last_edited_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_last_edited_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_last_edited_at"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_song_master_updated_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_song_master_updated_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_song_master_updated_at"() TO "service_role";



GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "service_role";


















GRANT ALL ON TABLE "public"."artists" TO "anon";
GRANT ALL ON TABLE "public"."artists" TO "authenticated";
GRANT ALL ON TABLE "public"."artists" TO "service_role";



GRANT ALL ON TABLE "public"."medley_edits" TO "anon";
GRANT ALL ON TABLE "public"."medley_edits" TO "authenticated";
GRANT ALL ON TABLE "public"."medley_edits" TO "service_role";



GRANT ALL ON TABLE "public"."medley_songs" TO "anon";
GRANT ALL ON TABLE "public"."medley_songs" TO "authenticated";
GRANT ALL ON TABLE "public"."medley_songs" TO "service_role";



GRANT ALL ON TABLE "public"."medleys" TO "anon";
GRANT ALL ON TABLE "public"."medleys" TO "authenticated";
GRANT ALL ON TABLE "public"."medleys" TO "service_role";



GRANT ALL ON TABLE "public"."song_artist_relations" TO "anon";
GRANT ALL ON TABLE "public"."song_artist_relations" TO "authenticated";
GRANT ALL ON TABLE "public"."song_artist_relations" TO "service_role";



GRANT ALL ON TABLE "public"."song_master" TO "anon";
GRANT ALL ON TABLE "public"."song_master" TO "authenticated";
GRANT ALL ON TABLE "public"."song_master" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































